#### A Simple Web Site

This is a simple web site that your server could host.

This is the file `index.html` and is the default web page. 

![](./p1.jpg)

Below should be a picture of Autumn leaves:

![](p3.png)

[An obligatory cat photo](./images/etc/p5.png)

[Some other photos](./images/photos.html)