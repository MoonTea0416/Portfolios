/**
 * ConfigurationException.java
 *
 */

public class ConfigurationException extends Exception
{
	public ConfigurationException(String exception) {
		super(exception);
	}
}
